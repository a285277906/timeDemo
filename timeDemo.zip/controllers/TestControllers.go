package controllers

import (
	"github.com/beego/beego/v2/server/web"
	jsoniter "github.com/json-iterator/go"
	"time"
	"timeDemo/models"
	"timeDemo/utils"
)

type TestControllers struct {
	web.Controller
}

var myJson jsoniter.API

func init() {
	myJson = jsoniter.ConfigCompatibleWithStandardLibrary //实例化工具类
}

type Res struct {
	V models.TestData
	D string
}

func (c *TestControllers) GetData() {
	v := models.TestData{Msg: "demo", TestTime1: time.Now().Local(), TestTime2: utils.NewTime()}
	a, _ := myJson.Marshal(v)
	res := Res{V: v, D: string(a)}
	c.Data["json"] = res
	_ = c.ServeJSON()
}
