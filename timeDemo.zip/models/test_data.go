package models

import (
	"time"
	"timeDemo/utils"
)

type TestData struct {
	Msg       string     `json:"msg"`
	TestTime1 time.Time  `json:"testTime1"`
	TestTime2 utils.Time `json:"testTime2"`
}
