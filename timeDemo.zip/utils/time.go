package utils

import (
	"encoding/json"
	"fmt"
	"github.com/beego/beego/v2/client/orm"
	"strings"
	"time"
)

type Time struct {
	time.Time
}

func NewTime() Time {
	runtime := Time{}
	runtime.Now()
	return runtime
}

func (t *Time) MarshalJSON() ([]byte, error) {
	if t.IsZero() {
		return []byte("\"\""), nil
	}
	stamp := fmt.Sprintf("\"%s\"", t.Format("2006-01-02 15:04:05"))
	return []byte(stamp), nil
}

func (t *Time) UnmarshalJSON(data []byte) error {
	var err error
	timeStr := string(data)
	timeStr = strings.ReplaceAll(timeStr, `"`, ``)
	if len(timeStr) == 10 {
		timeStr += " 00:00:00"
	}
	t.Time, err = time.ParseInLocation("2006-01-02 15:04:05", timeStr, time.Local)
	return err
}

func (t *Time) SetDefault() {
	t.Time, _ = time.ParseInLocation("2006-01-02 15:04:05", t.Format("2006-01-02 15:04:05"), time.Local)
}

// String 重写String方法
func (t *Time) String() string {
	data, _ := json.Marshal(t)
	return string(data)
}

// FieldType 数据类型
func (t *Time) FieldType() int {
	return orm.TypeDateTimeField

}

// SetRaw 读取数据库值
func (t *Time) SetRaw(value interface{}) error {
	switch value.(type) {
	case time.Time:
		t.Time = value.(time.Time)
	}
	return nil
}

// RawValue 写入数据库
func (t *Time) RawValue() interface{} {
	str := t.Format("2006-01-02 15:04:05")
	if str == "0001-01-01 00:00:00" {
		return nil
	}
	return str
}

func (t *Time) Now() {
	t.Time = time.Now().Local()
}
